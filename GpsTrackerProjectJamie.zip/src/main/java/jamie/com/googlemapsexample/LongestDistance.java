package jamie.com.googlemapsexample;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class LongestDistance extends AppCompatActivity{

    MyDBManager db;

    ListView list;

    //Array lists to store the information.

    ArrayList<Double> Start_Lat;

    ArrayList<Double> Start_Lon;

    ArrayList<Double> Start_Event;

    ArrayList<Double> Stop_Distance;

    ArrayList<Double> Stop_Duration;

    ArrayList<Double> Stop_Lat;

    ArrayList<Double> Stop_Lon;

    ArrayList<String> Start_Date;

    String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.longestdistance);

        //initialising the array lists.

        Start_Lat = new ArrayList<>();
        Start_Lon = new ArrayList<>();
        Start_Event =  new ArrayList<>();

        Stop_Lat = new ArrayList<>();
        Stop_Lon = new ArrayList<>();
        Stop_Distance = new ArrayList<>();
        Stop_Duration = new ArrayList<>();

        Start_Date = new ArrayList<>();

        db = new MyDBManager(this);

        db.open();

        // Carries over the user ID from the previous page

        Bundle bundle = getIntent().getExtras();

        id = bundle.getString("id");


        // Get the journeys in the journeys table of the user who is logged into the application

        get_Journeys(id);

        db.close();


        list = (ListView) findViewById(R.id.distance_stats);
        list.setAdapter(new MyCustomAdapter(LongestDistance.this, R.layout.row, Start_Event, Start_Lat, Start_Lon));


        list.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                double lat = Start_Lat.get(position);
                double lon = Start_Lon.get(position);

                //starting an intent.

                Intent i = new Intent(LongestDistance.this, Map.class);
                i.putExtra("start_lat", lat);
                i.putExtra("start_lon", lon);

                i.putExtra("stop_lat", Stop_Lat.get(position));
                i.putExtra("stop_lon", Stop_Lon.get(position));
                i.putExtra("id", id);
                startActivity(i);
            }
        });



    }


    public class MyCustomAdapter extends ArrayAdapter<Double> {

        ArrayList<Double> Adapter_Event;
        ArrayList<Double> Adapter_Lat;
        ArrayList<Double> Adapter_Lon;


        // Creating our own adaptor because we want to be able to customise each row

        public MyCustomAdapter(Context context, int textViewResourceId,ArrayList<Double> a, ArrayList<Double> b, ArrayList<Double> c)
        {
            super(context, textViewResourceId,a);
            // TODO Auto-generated constructor stub
            Adapter_Event=a;
            Adapter_Lat=b;
            Adapter_Lon=c;

        }

        @Override
        // This get view method is called each time a row needs to be formatted for the list

        public View getView(int position, View convertView, ViewGroup parent)
        {

            // TODO Auto-generated method stub
            //return super.getView(position, convertView, parent);

            LayoutInflater inflater=getLayoutInflater();
            View row=inflater.inflate(R.layout.row, parent, false);

            TextView date=(TextView)row.findViewById(R.id.date);
            //TextView mileage=(TextView)row.findViewById(R.id.mileage);
            //TextView duration=(TextView)row.findViewById(R.id.duration);

        //Displays the map image.

            ImageView icon = (ImageView) row.findViewById(R.id.icon);
            icon.setImageResource(R.drawable.map);

            date.setText("Start Date: " + Start_Date.get(position) + "\n" + "Distance: " + Stop_Distance.get(position) + "Km" + "\n" + "Duration: "+Stop_Duration.get(position)+"sec");
          //  mileage.setText(""+Stop_Distance.get(position)+"Km");
            //duration.setText(""+Stop_Duration.get(position)+"secs");

            return row;
        }
    }


    //Gets all of the journeys by that user - explanation of the method is contained with MyDBManager class.

    public void get_Journeys(String id) {
        Cursor c = db.getJourneyDistanceStarts(id);
        Cursor c2 = db.getJourneyDistanceStops(id);

        if (c.moveToFirst()) {
            do
            {

                ShowJourney(c, c2);

            }
            while (c.moveToNext()&&c2.moveToNext());
        }
    }

    public void ShowJourney(Cursor c, Cursor c2)
    {


        Start_Date.add((c.getString(6)));
        Start_Lat.add((c.getDouble(1)));
        Start_Event.add((c.getDouble(0)));
        Start_Lon.add((c.getDouble(2)));

        Stop_Lat.add((c2.getDouble(1)));
        Stop_Lon.add((c2.getDouble(2)));
        Stop_Duration.add((c2.getDouble(5)));
        Stop_Distance.add((c2.getDouble(4)));


    }




}

