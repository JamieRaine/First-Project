package jamie.com.googlemapsexample;



import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class JourneyRecording extends AppCompatActivity implements LocationListener {

    //declaring instance variables to store the information entered

    private MyDBManager db;

    private String db_journey_type;

    String id;



    TextView journeyType;
    private TextView locationText, locationText2, locationText3, locationText4;
    private LocationManager locationManager;
    Button button;

    boolean GPSenabled = false;

    boolean first_reading=true;

    //declaring instance variables to store the information entered

    double distance=0;
    double previous_lat,previous_lon;
    double lon,lat;
    double time;
    // double speed;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.journeyrecording);

        db = new MyDBManager(this);

        //linking the widgets back to the declaration made in the XML file

        button = (Button) findViewById(R.id.submit_button);
        locationText = (TextView) findViewById(R.id.distance);
        locationText2 = (TextView) findViewById(R.id.type);
        locationText3 = (TextView) findViewById(R.id.duration);
      //  locationText4 = (TextView) findViewById(R.id.speed);

        //Setting the text to be displayed on the page

        locationText.setText("Distance to be calculated");
        locationText2.setText("Mode of Transport");
        locationText3.setText("Journey Duration");
      //  locationText4.setText("Speed");

        setUpLocation();

        checkIsGpsEnabled();

        /* Carries over the user ID and journey type from the previous page.
        The journey type is then appended to the text view locationText2
         */

        Bundle bundle = getIntent().getExtras();

        db_journey_type = bundle.getString("Mode");
        locationText2.append(": " + db_journey_type);
        id = bundle.getString("id");

        //Allows the time elapsed to be recorded

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask()
        {
            public void run()
            {
                time++; //increments by one each time
            }
        }, 0, 1000); //increment by defined times


        //speed = distance/time;

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //starting an intent and passing the information contained within the instance variables to the next page

                Intent intent = new Intent(JourneyRecording.this, JourneyRecordingConfirmation.class);

                startActivity(intent);


                /*
                Opening the database and entering into it, the information contained within the instance variables.
                The user ID is bundled from previous page and is dependant upon wh is logged into the application.
                The event is hard coded to reflect start and stop positions.
                Previous lat, previous lon, lat and lon values are all calculated from within this class.
                Time is divided by 60 to achieve one minute.
                Distance is calculated within this class.
                Db journey type is bundled from the previous page and is dependant upon the journey mode selected.
                Date is calculated from within this class.
                 */

                String date = new SimpleDateFormat("yyyy.MM.dd").format(Calendar
                        .getInstance().getTime());

                db.open();

                db.insertTask(id, 1, previous_lat, previous_lon, time/60, distance, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, time/60, distance,  db_journey_type, date); //speed = distance/time

            /*    db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 500, 489, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 1, 1, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 45, 88, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 17, 25, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 99, 45, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 72, 149, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 320, 200, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 400, 689, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 120, 110, db_journey_type, date);

                db.insertTask(id, 1, previous_lat, previous_lon, 0, 0, db_journey_type, date);
                db.insertTask(id, 3, lat, lon, 30, 40, db_journey_type, date);  */

                db.close();

            }
        });



    }



    // call back method
    public void onLocationChanged(Location location) {
        String latestLocation = "";

        if (location != null) {
            if(first_reading)
            {
                if(location.getLatitude()!=0 && location.getLongitude()!=0) {

                    previous_lat = location.getLatitude();

                    previous_lon = location.getLongitude();

                    first_reading = false;

                    distance=0;


                }
            }

            else
            {


                lon = location.getLongitude();
                lat=location.getLatitude();

                // Calculates the distance

                double dlong = toRad(lon - previous_lon);
                double dlat = toRad(lat - previous_lat);
                double a =
                        Math.pow(Math.sin(dlat / 2.0), 2)
                                + Math.cos(toRad(previous_lat))
                                * Math.cos(toRad(location.getLatitude()))
                                * Math.pow(Math.sin(dlong / 2.0), 2);
                double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                double d = 6367 * c;


                distance = distance + d;



                previous_lat=lat;

                previous_lon=lon;




                String date = new SimpleDateFormat("yyyy.MM.dd").format(Calendar
                        .getInstance().getTime());

                db = new MyDBManager(this);


                db.open();








                previous_lat=lat;

                previous_lon=lon;
            }
        }
        Toast.makeText(JourneyRecording.this, previous_lat+" "+previous_lon,
                Toast.LENGTH_LONG).show();

        //Displayes the distance and time calculations to the user as the recording is being made.

        locationText.setText(distance+"kms");
        locationText3.setText(time + " seconds");
        //locationText4.setText(speed + "K/M P/H");
    }

    private Double toRad(Double value) {
        return value * Math.PI / 180;
    }

    public void onProviderDisabled(String provider) {
        // Code to do something if location provider is disabled e.g. display error
    }

    public void onProviderEnabled(String provider) {
        // Code to do something if location provider becomes available e.g check if it’s a  more useful provider
    }

    public void onStatusChanged(String provider, int status, Bundle extras) {
        // Code to do something if location provider status changes..
    }


    // custom method
    private void setUpLocation() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);




        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                60000,
                5,
                this);
    }

    /**
     * Register for the updates when Activity is in foreground i.e. only use up the battery power if you have to..
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                60000,
                5,
                this);
    }


    /**
     * Stop the updates when Activity is paused i.e. save your battery
     */
    @Override
    protected void onPause() {
        super.onPause();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.removeUpdates(this);
    }


    private void showAlertDialogNoGPS()
    {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(	"Your handset's GPS location function is disabled and without it the application cannot run")
                .setCancelable(false)
                .setPositiveButton("Enable GPS",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialog,final int id) {
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivityForResult(intent, 3); 		// will come back to onActivityResult()
                    }
                })
                .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialog, final int id) {
                        // Finishes all acivities currently open
                        finish();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    private void checkIsGpsEnabled()
    {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            GPSenabled = false;
            showAlertDialogNoGPS();
        }
        else
            GPSenabled = true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 3 && resultCode == 0) {
            String provider = Settings.Secure.getString(getContentResolver(),Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
            if (provider != null) {
                if ((provider.contains("gps")) || (provider.contains("GPS"))) {
                    GPSenabled = true;
                    return;	// gps enabled - go ahead
                }
                else{
                    GPSenabled = false;


                }
            }else{
                GPSenabled = false;
            }
            Toast.makeText(this,"GPS satellites location still not enabled",	Toast.LENGTH_LONG).show();
            finish();
        }


    }

}

