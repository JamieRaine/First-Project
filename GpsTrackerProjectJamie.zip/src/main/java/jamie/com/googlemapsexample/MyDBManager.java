package jamie.com.googlemapsexample;


import android.database.Cursor;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Timer;

public class MyDBManager
{

    //Creates the database, two tables and the columns of each table table.

    public static final String KEY_ROWID = "_id";
    public static final String KEY_USERID = "user_id";
    public static final String KEY_EVENT = "event_type";
    public static final String KEY_LAT = "latitude";
    public static final String KEY_LON = "longitude";
    public static final String KEY_DIST = "distance";
    public static final String KEY_DUR = "duration";
    public static final String KEY_TIME = "time";
    public static final String KEY_MODE = "mode";
    // public static final String KEY_SPEED = "speed";

    public static final String KEY_USERNAME = "username";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_PREFERENCE = "preference";



    private static final String DATABASE_NAME = "Journey";
    private static final String DATABASE_TABLE = "Journey_Details";

    private static final String DATABASE_TABLE2 = "User_Details";


    private static final int DATABASE_VERSION = 1;

    //
    private static final String DATABASE_CREATE2 = "create table User_Details " +
            "(_id integer primary key autoincrement, "+
            "username text not null, " +"password text not null, " +"preference text not null);";

    private static final String DATABASE_CREATE = "create table Journey_Details " +
            "(_id integer primary key autoincrement, " + "user_id string not null, "+
            "event_type double not null, " +"latitude double not null, " + "distance double not null, "+
            "duration double not null, " + "time date not null, "+"mode string not null, " +"longitude double not null);"; // " +"speed double not null);";



    private final Context context;

    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;

    //
    public MyDBManager(Context ctx)
    {
        //
        this.context = ctx;
        DBHelper = new DatabaseHelper(context);
    }


    //
    private static class DatabaseHelper extends SQLiteOpenHelper
    {

        //
        DatabaseHelper(Context context)
        {
            super(context, DATABASE_NAME,
                    null, DATABASE_VERSION);
        }


        @Override
        //
        public void onCreate(SQLiteDatabase db)
        {

            db.execSQL(DATABASE_CREATE);
            db.execSQL(DATABASE_CREATE2);
        }

        @Override

        //
        public void onUpgrade(SQLiteDatabase db, int oldVersion,
                              int newVersion)
        {
            // whatever is to be changed on dB structure

        }
    }   //


    //
    public MyDBManager open() throws SQLException
    {
        db = DBHelper.getWritableDatabase();
        return this;
    }

    //
    public void close()
    {
        DBHelper.close();
    }

    //This method inserts the users, password, unit of measurement preference and username into the database
    //It is called from the registration class

    public long insertUser(String user, String pass, String preference)    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_USERNAME, user);
        initialValues.put(KEY_PASSWORD, pass);
        initialValues.put(KEY_PREFERENCE, preference);

        return db.insert(DATABASE_TABLE2, null, initialValues);
    }

    //This method is to get individual users but isn't called within the application

    public Cursor getUsers(String user, String password)
    {
        return db.query(true, DATABASE_TABLE2, new String[]{
                        KEY_ROWID,
                        KEY_USERNAME,
                        KEY_PASSWORD,
                        KEY_PREFERENCE
                },
                KEY_USERNAME + "=\"" + user + "\" AND " + KEY_PASSWORD + "=\"" + password + "\"",
                null,
                null,
                null,
                null,
                null);
    }

//This method brings back all of the users information from the database.
    //It is called from the ViewDatabase class.

    public Cursor getAllUsers()
    {
        return db.query(DATABASE_TABLE2, new String[]{
                        KEY_ROWID,
                        KEY_USERNAME,
                        KEY_PASSWORD,
                        KEY_PREFERENCE,

                },
                null,
                null,
                null,
                null,
                null);
    }

    //This method inserts the recorded journey into the database.
    //It is called from the JourneyRecording class.


    public long insertTask(String user_id,int event, double lat, double lon, double duration,double distance, String mode, String date)
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_USERID, user_id);
        initialValues.put(KEY_EVENT, event);
        initialValues.put(KEY_LAT, lat);
        initialValues.put(KEY_LON,lon);
        initialValues.put(KEY_DIST, distance);
        initialValues.put(KEY_DUR, duration);
        initialValues.put(KEY_MODE, mode);
        initialValues.put(KEY_TIME, date);
        //  initialValues.put(KEY_SPEED, speed);

        return db.insert(DATABASE_TABLE, null, initialValues);
    }

    //This method gets all journeys from the database.
    //It is called from the JourneyData class.

    public Cursor getAllJourneys(String id) throws SQLException {
        Cursor mCursor =
                db.query(true, DATABASE_TABLE, new String[]{
                                KEY_ROWID,
                                KEY_EVENT,
                                KEY_LON,
                                KEY_LAT,
                                KEY_DIST,
                                KEY_DUR,
                                KEY_MODE,
                                KEY_TIME,
                                KEY_USERID,


                        },

                        null,
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    //This method is to delete the journeys recorded. It is not used within the app.

    public boolean deleteTask(long rowId)
    {
        //
        return db.delete(DATABASE_TABLE, KEY_ROWID +
                "=" + rowId, null) > 0;
    }

    //This method returns all of the journeys of the user who is logged in to the application. It does this by taking the ID as a parameter.
    //It is called from the Results class together with the getStops method below.

    public Cursor getStarts(String id)
    {
        Cursor mCursor = db.query(true,DATABASE_TABLE, new String[] {
                        KEY_ROWID,
                        KEY_LAT,
                        KEY_LON,
                        KEY_EVENT,
                        KEY_DIST,
                        KEY_DUR,
                        KEY_TIME,
                        KEY_MODE
                },
                KEY_USERID + "=\"" + id + "\"" + " AND " + KEY_EVENT + "=\"" + 1 + "\"",
                null,
                null,
                null,
                null,
                null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public Cursor getStops(String id)
    {
        Cursor mCursor = db.query(true,DATABASE_TABLE, new String[] {
                        KEY_ROWID,
                        KEY_LAT,
                        KEY_LON,
                        KEY_EVENT,
                        KEY_DIST,
                        KEY_DUR,
                        KEY_MODE
                },
                KEY_USERID + "=\"" + id + "\"" + " AND " + KEY_EVENT + "=\"" + 3 + "\"",
                null,
                null,
                null,
                null,
                null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    //This method checks whether the username is already registered within the database.
    //It is called from the Registration class


    public boolean checkRegistered(String id) throws SQLException{
        String query = "Select username from User_Details where username = '" + id + "'";
        Cursor mCursor = db.rawQuery(query, null);
        if(mCursor !=null){
            mCursor.moveToFirst();
        }
        try {
            String username = mCursor.getString(mCursor.getColumnIndex("username"));

            if(username.equals(username)){
                return true;
            }else {
                return false;
            }
        }catch (CursorIndexOutOfBoundsException e){
            return false;
        }
    }

    //This method checks if the username and password match those held in the user details table in the database.
    //It is called from the LogIn class.

    public String getLogin(String userName)
{
    Cursor cursor=db.query("user_details", null, " username=?", new String[]{userName}, null, null, null);
    if(cursor.getCount()<1) // UserName Not Exist
    {
        cursor.close();
        return "DOES NOT EXIST";
    }
    cursor.moveToFirst();
    String password= cursor.getString(cursor.getColumnIndex("password"));
    cursor.close();
    return password;
    }

    //This method returns the top 10 journeys of the user who is logged in to the application ordering them by distance traveled.
    // It does this by taking the ID as a parameter to match it to the logged in user, checks the starts and stops and the distance travelled.
    //It is called from the LongestDistance class

    public Cursor getJourneyDistanceStarts(String id)
    {
        Cursor mCursor = db.query(true,DATABASE_TABLE, new String[] {
                        KEY_ROWID,
                        KEY_LAT,
                        KEY_LON,
                        KEY_EVENT,
                        KEY_DIST,
                        KEY_DUR,
                        KEY_TIME,
                        KEY_MODE
                },
                KEY_USERID + "=\"" + id + "\"" + " AND " + KEY_EVENT + "=\"" + 1 + "\"" + " order by distance desc limit 10",
                null,
                null,
                null,
                null,
                null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public Cursor getJourneyDistanceStops(String id)
    {
        Cursor mCursor = db.query(true,DATABASE_TABLE, new String[] {
                        KEY_ROWID,
                        KEY_LAT,
                        KEY_LON,
                        KEY_EVENT,
                        KEY_DIST,
                        KEY_DUR,
                        KEY_MODE
                },
                KEY_USERID + "=\"" + id + "\"" + " AND " + KEY_EVENT + "=\"" + 3 + "\"" + " order by distance desc limit 10",
                null,
                null,
                null,
                null,
                null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    //This method returns the top 10 journeys of the user who is logged in to the application ordering them by journey time.
    // It does this by taking the ID as a parameter to match it to the logged in user, checks the starts and stops and the time taken.
    //It is called from the LongestDuration class

    public Cursor getJourneyDurationStarts(String id)
    {
        Cursor mCursor = db.query(true,DATABASE_TABLE, new String[] {
                        KEY_ROWID,
                        KEY_LAT,
                        KEY_LON,
                        KEY_EVENT,
                        KEY_DIST,
                        KEY_DUR,
                        KEY_TIME,
                        KEY_MODE
                },
                KEY_USERID + "=\"" + id + "\"" + " AND " + KEY_EVENT + "=\"" + 1 + "\"" + " order by duration desc limit 10",
                null,
                null,
                null,
                null,
                null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public Cursor getJourneyDurationStops(String id)
    {
        Cursor mCursor = db.query(true, DATABASE_TABLE, new String[]{
                        KEY_ROWID,
                        KEY_LAT,
                        KEY_LON,
                        KEY_EVENT,
                        KEY_DIST,
                        KEY_DUR,
                        KEY_MODE
                },
                KEY_USERID + "=\"" + id + "\"" + " AND " + KEY_EVENT + "=\"" + 3 + "\"" + " order by duration desc limit 10",
                null,
                null,
                null,
                null,
                null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    //This method gets individual journeys of the user logged into the application. It does this by taking the ID of the
    //logged in user and the journey mode selected.
    //It is never called within the application.


    public Cursor getStarts(String id, String mode)
    {
        Cursor mCursor = db.query(true,DATABASE_TABLE, new String[] {
                        KEY_ROWID,
                        KEY_LAT,
                        KEY_LON,
                        KEY_EVENT,
                        KEY_DIST,
                        KEY_DUR,
                        KEY_TIME,
                        KEY_MODE
                },
                KEY_USERID + "=\"" + id + "\"" + " AND " + KEY_EVENT + "=\"" + 1 + "\"" + " AND " + KEY_MODE + "=\"" + mode + "\"",
                null,
                null,
                null,
                null,
                null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public Cursor getStops(String id, String mode)
    {
        Cursor mCursor = db.query(true,DATABASE_TABLE, new String[] {
                        KEY_ROWID,
                        KEY_LAT,
                        KEY_LON,
                        KEY_EVENT,
                        KEY_DIST,
                        KEY_DUR,
                        KEY_MODE
                },
                KEY_USERID + "=\"" + id + "\"" + " AND " + KEY_EVENT + "=\"" + 3 + "\"" + " AND " + KEY_MODE + "=\"" + mode + "\"",
                null,
                null,
                null,
                null,
                null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }


}