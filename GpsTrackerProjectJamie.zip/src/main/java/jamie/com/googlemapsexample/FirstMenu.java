package jamie.com.googlemapsexample;


import android.support.v7.app.AppCompatActivity;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstMenu extends AppCompatActivity {

    //declaring the various widgets to be used

    private Button register;
    private Button login;


    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.firstmenu);

        //linking the widgets back to the declaration made in the XML file

        register = (Button)findViewById(R.id.register);
        login = (Button)findViewById(R.id.login);

        //Two buttons to take the user to either register or login to the application

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FirstMenu.this, Registration.class);
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FirstMenu.this, LogIn.class);
                startActivity(intent);
            }
        });



    }}
