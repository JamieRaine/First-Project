package jamie.com.googlemapsexample;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LogIn extends AppCompatActivity {

    private MyDBManager db;

    //declaring instance variables to store the information entered

    String db_password;
    String id;

    //declaring the various widgets to be used

    EditText username, password;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        db = new MyDBManager(this);

        //linking the widgets back to the declaration made in the XML file

        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        button = (Button)findViewById(R.id.login);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Getting the information entered in the edit texts fields.

                id = username.getText().toString();
                db_password = password.getText().toString();

                //Checks to ensure that information is entered into both fields

                if (id.equals("")){
                    Toast.makeText(getApplicationContext(),"Please enter your username", Toast.LENGTH_LONG).show();
                }
                if (db_password.equals("")) {
                    Toast.makeText(getApplicationContext(),"Please enter your password", Toast.LENGTH_LONG).show();
                }
                if (id.equals("") && db_password.equals("")){
                    Toast.makeText(getApplicationContext(),"Please complete all fields", Toast.LENGTH_LONG).show();
                }

                //if the password and username entered, match information in the database, the user will be logged in.
                //if it doesn't, a message will be displayed to the user.

                if(!id.equals("") && !db_password.equals("")) {
                    db.open();
                    String storedPassword = db.getLogin(id);

                    if(db_password.equals(storedPassword)) {
                        db.close();
                        Intent intent = new Intent(LogIn.this, MainMenu.class);
                        intent.putExtra("id", id);
                        startActivity(intent);
                        finish();
                    }else{
                        Toast.makeText(getApplicationContext(),"User name or password does not match", Toast.LENGTH_LONG).show();
                    }



                }

            }
        });


    }
}
