package jamie.com.googlemapsexample;


import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ViewDatabase extends AppCompatActivity {

    private MyDBManager db;
    LinearLayout container, container2;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewdatabase);

        container = (LinearLayout)findViewById(R.id.database);

        db = new MyDBManager(this);

        db.open();

        getRows();

        db.close();

    }


    //calls the method getAllUsers from the MyDBMangager class to return
    //the users ID, username, password and unit of selection.
    public void getRows() {
        Cursor c = db.getAllUsers();
        if (c.moveToFirst()) {
            do {
                ShowTask(c);

            }
            while (c.moveToNext());
        }
    }

    public void ShowTask(Cursor c)
    {

        TextView text = new TextView(this);

        //returns the results and prints them out in a TextView, appending the results at the specified position.

        text.setText("id: " + c.getString(0) + "\n" +
                        "Username: " + c.getString(1) + "\n" +
                        "Password: " + c.getString(2) + "\n" +
                        "Unit of Distance: " + c.getString(3) + "\n"

        );

        container.addView(text);

    }

}
