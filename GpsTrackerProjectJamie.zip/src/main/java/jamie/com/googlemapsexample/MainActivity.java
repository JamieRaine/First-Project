package jamie.com.googlemapsexample;




import android.support.v7.app.AppCompatActivity;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //declaring the various widgets to be used


    private Button app;
    private Button database;


    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //linking the widgets back to the declaration made in the XML file

        app = (Button)findViewById(R.id.app);
        database = (Button)findViewById(R.id.database2);


        //Two buttons; one to take the user to the app and the other to view the database of registered users.

        app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FirstMenu.class);
                startActivity(intent);
            }
        });

        database.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ViewDatabase.class);
                startActivity(intent);
            }
        });



    }}
