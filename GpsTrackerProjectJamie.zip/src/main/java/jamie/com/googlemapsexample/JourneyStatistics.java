package jamie.com.googlemapsexample;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class JourneyStatistics extends AppCompatActivity {

    //declaring the various widgets to be used

    Spinner spinner;
    Button button1;
    Button button2;
    Button button3;
    Button button4;

    //declaring instance variables to store the information entered

    String db_journey_type;
    String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.journeystatistics);

        //linking the widgets back to the declaration made in the XML file

        spinner = (Spinner) findViewById(R.id.journey_type);
        button1 = (Button) findViewById(R.id.category);
        button2 = (Button) findViewById(R.id.view_map);
        button3 = (Button) findViewById(R.id.view_time_stats);
        button4 = (Button) findViewById(R.id.view_distance_stats);

        // Carries over the user ID from the previous page

        Bundle bundle = getIntent().getExtras();
        id = bundle.getString("id");

        //create a list of strings for the spinner

        List<String> list = new ArrayList<String>();
        list.add("All");
        list.add("Driving");
        list.add("Walking");
        list.add("Jogging");
        list.add("Cycling");


        ArrayAdapter<String> dataadapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);

        dataadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(dataadapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {


                db_journey_type = parent.getItemAtPosition(pos).toString();
            }

            public void onNothingSelected(AdapterView<?> paren) {

                db_journey_type = "All";

            }

        });




        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //starting an intent and passing the information contained within the instance variables to the next page

                Intent intent = new Intent(JourneyStatistics.this, JourneyData.class);
                intent.putExtra("Journey Mode", db_journey_type);

                startActivity(intent);
            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //starting an intent and passing the information contained within the instance variables to the next page

                Intent intent = new Intent(JourneyStatistics.this, Results.class);
                intent.putExtra("id", id);
                intent.putExtra("mode", db_journey_type);

                startActivity(intent);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //starting an intent and passing the information contained within the instance variables to the next page

                Intent intent = new Intent(JourneyStatistics.this, LongestDuration.class);
                intent.putExtra("id", id);

                startActivity(intent);
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //starting an intent and passing the information contained within the instance variables to the next page

                Intent intent = new Intent(JourneyStatistics.this, LongestDistance.class);
                intent.putExtra("id", id);

                startActivity(intent);
            }
        });


    }


}
