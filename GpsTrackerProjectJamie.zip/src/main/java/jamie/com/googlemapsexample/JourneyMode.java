package jamie.com.googlemapsexample;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class JourneyMode extends AppCompatActivity {

    //declaring the various widgets to be used

    Spinner Journey_Type;
    Button button;

    //declaring instance variables to store the information entered

    private String db_journey_type;
    private MyDBManager db;

    String id;


    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.journeymode);

        //calling the MyDBManager class to access the methods within

        db = new MyDBManager(this);

        //linking the widgets back to the declaration made in the XML file

        Journey_Type = (Spinner) findViewById(R.id.journey_mode);
        button = (Button) findViewById(R.id.recording_button);

        // Carries over the user ID from the previous page

        Bundle bundle = getIntent().getExtras();
        id = bundle.getString("id");

        //create a list of strings for the spinner

        List<String> list = new ArrayList<String>();
        list.add("Driving");
        list.add("Walking");
        list.add("Jogging");
        list.add("Cycling");


        ArrayAdapter<String> dataadapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);

        dataadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Journey_Type.setAdapter(dataadapter);

        Journey_Type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

              /*  Toast.makeText(parent.getContext(), "On Item " +
                                "Selected" + parent.getItemAtPosition(pos).toString(),
                        Toast.LENGTH_LONG).show(); */

                db_journey_type = parent.getItemAtPosition(pos).toString();
            }

            public void onNothingSelected(AdapterView<?> paren) {

                db_journey_type = "Driving";

            }

        });

        //this button takes the user to the next page

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //starting an intent and passing the information contained within the instance variables to the JourneyRecording page.

                if (db_journey_type !=null) {

                    Intent intent = new Intent(JourneyMode.this, JourneyRecording.class);
                    intent.putExtra("Mode", db_journey_type);
                    intent.putExtra("id", id);
                    startActivity(intent);
                }

            }
        });


    }}

