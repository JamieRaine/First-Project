package jamie.com.googlemapsexample;


import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class Map extends FragmentActivity implements OnMapReadyCallback {


    GoogleMap mMap;

    //declaring instance variables to store the information entered

    double lat;
    double lon;
    double stop_lat;
    double stop_lon;
    String id;

    //declaring the various widgets to be used

    Button Normal;
    Button Hybrid;
    Button Sat;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);

        // Carries over the user ID, lat, lon, stop_lat and stop_lon from the previous page

        Bundle bundle = getIntent().getExtras();



        if(bundle!= null)
        {
            lat = bundle.getDouble("start_lat");
            lon = bundle.getDouble("start_lon");
            stop_lat = bundle.getDouble("stop_lat");
            stop_lon = bundle.getDouble("stop_lon");
            id = bundle.getString("id");

        }

        //Three buttons; One to set the map type to a normal map,
        // another to set the map type to a satellite map and
        // the final one to display a hybrid map.

        Normal = (Button)findViewById(R.id.button1);
        Normal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            }
        });

        Sat = (Button)findViewById(R.id.button2);

        Sat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
            }
        });
        Hybrid = (Button)findViewById(R.id.button3);
        Hybrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
            }
        });

        //finds the map fragment

        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Gets the start and stop latitude and longitude

        LatLng start = new LatLng(lat, lon);
        LatLng stop = new LatLng(stop_lat, stop_lon);

        //Allows a marker to be positioned at the start and stop positions of the journey

        mMap.addMarker(new MarkerOptions().position(start).title("Start"));
        mMap.addMarker(new MarkerOptions().position(stop).title("Stop"));

        //This method positions the centre of the map at the position

        mMap.moveCamera(CameraUpdateFactory.newLatLng(start));

        //This method sets the zoom level of the view....

        mMap.moveCamera(CameraUpdateFactory.zoomTo(1));

     /*   if (ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
                 ==PackageManager.PERMISSION_GRANTED){
            mMap.setMyLocationEnabled(true);
        }
        else
        {
// Show rationale and request permission.
        }*/

        /// This allows the user to zoom in and out of the map

        mMap.getUiSettings().setZoomControlsEnabled(true);


    }
}
