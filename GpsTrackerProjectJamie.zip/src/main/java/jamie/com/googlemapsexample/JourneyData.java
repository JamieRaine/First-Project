package jamie.com.googlemapsexample;


import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class JourneyData extends AppCompatActivity {

    // Variables declared

    private MyDBManager db;
    LinearLayout container;
    String id;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.journeydata);

        //linking the widgets back to the declaration made in the XML file

        container = (LinearLayout) findViewById(R.id.database);
        db = new MyDBManager(this);

        // Carries over the user ID from the previous page

        Bundle bundle = getIntent().getExtras();
        id = bundle.getString("id");

        db.open();
        getRows(id);
        db.close();

    }


    // View the database

    public void getRows(String id) {

        //Calls the getAllJourneys method from the MyDBManagerClass

        Cursor c = db.getAllJourneys(id);
        if (c.moveToFirst()) {
            do {
                ShowJourney(c);
            }
            while (c.moveToNext());
        }
    }
    public void ShowJourney(Cursor c)
    {


        //returns the results and prints them out in a TextView, appending the results at the specified position.

        TextView text = new TextView(this);


        text.setText(
                "ID: " + c.getString(8) + "\n" +
                        "Date: " + c.getString(7)+ "\n" +
                        "Distance: " + c.getString(4) +  " kilometers"+ "\n" +
                        "Duration: " + c.getString(5) + " minute(s)" +"\n" +
                        "Lon: " + c.getString(2) + "\n" +
                        "Lat: " + c.getString(3) + "\n" +
                        "Mode: " + c.getString(6) + "\n" +
                        "Event: " + c.getString(1) + "\n"

                //"Average Speed: " + c.getString(9) + "m/s"+ "\n"
        );
        container.addView(text);
    }
}

