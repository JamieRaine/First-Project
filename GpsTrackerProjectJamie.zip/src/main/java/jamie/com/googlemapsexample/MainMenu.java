package jamie.com.googlemapsexample;


import android.support.v7.app.AppCompatActivity;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainMenu extends AppCompatActivity {

    //declaring the various widgets to be used

    private Button recording;
    private Button previousJourneys;

    //declaring instance variables to store the information entered

    String id;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu);

        //linking the widgets back to the declaration made in the XML file

        recording = (Button) findViewById(R.id.recording);
        previousJourneys = (Button) findViewById(R.id.previous_journeys);

        // Carries over the user ID from the previous page

        Bundle bundle = getIntent().getExtras();
        id = bundle.getString("id");

        //Two buttons; one to take the user to the Journey Mode selection and the other to take the user to the statistics page.

        recording.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenu.this, JourneyMode.class);
                intent.putExtra("id", id);
                startActivity(intent);
            }
        });

        previousJourneys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenu.this, JourneyStatistics.class);
                intent.putExtra("id", id);
                startActivity(intent);
            }
        });

    }
}
