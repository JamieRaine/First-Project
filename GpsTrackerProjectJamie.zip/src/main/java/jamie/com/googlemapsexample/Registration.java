package jamie.com.googlemapsexample;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    private MyDBManager db;

    //declaring instance variables to store the information entered. The information
    // stored in the edit text fields will be entered into the database.

    String id;
    String db_password;

    private String db_unit;
    EditText username, password;

    //declaring the various widgets to be used

    Button button;
    RadioGroup rdGroup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);

        db = new MyDBManager(this);

        //linking the widgets back to the declaration made in the XML file

        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        button = (Button)findViewById(R.id.register);
        rdGroup = (RadioGroup)findViewById(R.id.units);


        //A radio group to give the user the option of selecting Kilometers or miles per hour.

        rdGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup arg0, int id) {
                if (!rdGroup.isSelected()) {
                    switch (id) {
                        case R.id.radio0:
                            db_unit = "Kilometers per Hour";
                            break;
                        case R.id.radio1:
                            db_unit = "Miles per Hour";
                            break;
                        default:
                            break;

                    }
                }
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                id = username.getText().toString();
                db_password = password.getText().toString();



                if (id.equals("") || db_password.equals("")){
                    Toast.makeText(getApplicationContext(),"Please enter your username", Toast.LENGTH_LONG).show();
                }

                if (db_unit == null){
                    Toast.makeText(getApplicationContext(),"Please select a unit of measurement", Toast.LENGTH_LONG).show();
                }

                //Adds the information into the database provided all fields have been completed by the user.

                if (!id.equals("") && !db_password.equals("") && db_unit != null) {

                    db.open();

                    //This checks if the username is already registered in the database. It compares the username entered against
                    //those already stored.

                    boolean registrationCheck = db.checkRegistered(id);
                    if (!registrationCheck){
                        db.insertUser(id, db_password, db_unit);
                        db.close();
                        Intent intent = new Intent(Registration.this, LogIn.class);

                        startActivity(intent);
                    }else {
                        Toast.makeText(getApplicationContext(), "This username already exists", Toast.LENGTH_LONG).show();
                    }

                }
            }
        });



    }
}
